
## Bajaj Finserv Health Track 3rd round task
### Problem statement
Build and host a REST API with one endpoint that accepts requests with both GET and POST methods.
POST method endpoint takes in the request (JSON) and returns the following:
1. Status
2. User ID
3. College Email ID
4. College Roll Number
5. Array for numbers
6. Array for alphabets
7. Highest Alphabet in the input array of alphabets
GET method endpoint doesn’t take any user input, it just returns an operation_code

### Deployed site
https://bfhl-kjgc.onrender.com/bfhl
